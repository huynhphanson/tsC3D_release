@echo off
title tsC3D Setup ^& Self-Diagnostics (Civil 3D)
set "WORKER=%~dp0bundle\Contents\setup_worker.ps1"
if /I "%~1"=="-Silent" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%WORKER%" -Mode Install
    exit /b %ERRORLEVEL%
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%WORKER%" -Mode Menu
