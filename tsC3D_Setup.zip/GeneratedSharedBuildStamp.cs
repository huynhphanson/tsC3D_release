﻿namespace tsC3D.Core
{
    internal static class TsC3DSharedBuildStamp
    {
        public static readonly string Version = "1.1.5";
        public static readonly string ManifestUrl = "https://raw.githubusercontent.com/huynhphanson/tsC3D_release/main/manifest.json";
        public static readonly string TelemetryUrl = "https://tsc3d-telemetry.tilesmodel.workers.dev";
        public static readonly string[] EnabledModules = new string[] { "Basemap" };
    }
}