﻿param(
    [string]$Mode = "Menu"
)

$ErrorActionPreference = "Continue"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
$scriptDir = $PSScriptRoot
$rootSetupDir = Split-Path -Parent (Split-Path -Parent $scriptDir)
if (-not (Test-Path (Join-Path $rootSetupDir "bundle\PackageContents.xml"))) {
    $rootSetupDir = Split-Path -Parent $scriptDir
}

function Unblock-AllSetupFiles($dir) {
    try {
        Get-ChildItem -Path $dir -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
            Unblock-File -LiteralPath $_.FullName -ErrorAction SilentlyContinue
        }
    } catch { }
}

function Find-InstalledCivil3D {
    $catalog = @(
        @{ Year = 2027; Series = "R25.2"; Net = "net8" },
        @{ Year = 2026; Series = "R25.1"; Net = "net8" },
        @{ Year = 2025; Series = "R25.0"; Net = "net8" },
        @{ Year = 2024; Series = "R24.3"; Net = "net48" },
        @{ Year = 2023; Series = "R24.2"; Net = "net48" },
        @{ Year = 2022; Series = "R24.1"; Net = "net48" }
    )
    $found = @()
    foreach ($v in $catalog) {
        $candDirs = New-Object System.Collections.Generic.List[string]
        $hklmSeries = "HKLM:\SOFTWARE\Autodesk\AutoCAD\$($v.Series)"
        if (Test-Path $hklmSeries) {
            Get-ChildItem -Path $hklmSeries -ErrorAction SilentlyContinue | ForEach-Object {
                $loc = (Get-ItemProperty -Path $_.PSPath -Name "AcadLocation" -ErrorAction SilentlyContinue).AcadLocation
                if (-not [string]::IsNullOrWhiteSpace($loc)) { $candDirs.Add($loc.Trim()) }
            }
        }
        foreach ($drv in @("C", "D", "E", "F")) {
            $candDirs.Add("${drv}:\Program Files\Autodesk\AutoCAD $($v.Year)")
        }

        foreach ($dir in ($candDirs | Select-Object -Unique)) {
            if ((Test-Path (Join-Path $dir "AcCoreMgd.dll")) -and (Test-Path (Join-Path $dir "C3D\AeccDbMgd.dll"))) {
                $found += [PSCustomObject]@{
                    Year   = $v.Year
                    Series = $v.Series
                    Net    = $v.Net
                    Dir    = $dir
                    RegKey = "HKCU:\Software\Autodesk\AutoCAD\$($v.Series)"
                }
                break
            }
        }
    }
    return $found
}

function Register-AutoCadTrustedPath($regSeriesPath, $bundleContentsPath) {
    if (-not (Test-Path $regSeriesPath)) { return }
    Get-ChildItem -Path $regSeriesPath -ErrorAction SilentlyContinue | ForEach-Object {
        $profilesRoot = Join-Path $_.PSPath "Profiles"
        if (Test-Path $profilesRoot) {
            Get-ChildItem -Path $profilesRoot -ErrorAction SilentlyContinue | ForEach-Object {
                $varsKey = Join-Path $_.PSPath "Variables"
                if (Test-Path $varsKey) {
                    try {
                        Set-ItemProperty -Path $varsKey -Name "APPAUTOLOAD" -Value 14 -ErrorAction SilentlyContinue
                        $curTrust = (Get-ItemProperty -Path $varsKey -Name "TRUSTEDPATHS" -ErrorAction SilentlyContinue).TRUSTEDPATHS
                        $trustEntry = "$bundleContentsPath..."
                        if ([string]::IsNullOrEmpty($curTrust)) {
                            Set-ItemProperty -Path $varsKey -Name "TRUSTEDPATHS" -Value $trustEntry -ErrorAction SilentlyContinue
                        } elseif ($curTrust -notlike "*tsC3D.bundle*") {
                            Set-ItemProperty -Path $varsKey -Name "TRUSTEDPATHS" -Value ($curTrust.TrimEnd(';') + ";" + $trustEntry) -ErrorAction SilentlyContinue
                        }
                    } catch { }
                }
            }
        }
    }
}

function Invoke-InstallBundle {
    Write-Host ""
    Write-Host "=== CAI DAT CONG CU TSC3D CHO AUTODESK CIVIL 3D ===" -ForegroundColor Cyan
    Unblock-AllSetupFiles $rootSetupDir

    # Check if AutoCAD / Civil 3D is currently running (closing CAD first ensures TRUSTEDPATHS isn't overwritten by CAD on exit!)
    $runningAcad = @(Get-Process -Name "acad" -ErrorAction SilentlyContinue)
    if ($runningAcad.Count -gt 0 -and $Mode -ine "Install") {
        Write-Host "[!] PHAT HIEN CIVIL 3D / AUTOCAD DANG MO!" -ForegroundColor Yellow
        Write-Host "    De AutoCAD nhan quyen TRUSTEDPATHS ngay lan dau (khong hoi bang Security)," -ForegroundColor Yellow
        Write-Host "    hay LUU BAN VE & DONG CIVIL 3D truoc, sau do nhan Enter de tiep tuc..." -ForegroundColor Yellow
        Read-Host "    Nhan Enter sau khi da dong Civil 3D"
    }

    $c3dList = @(Find-InstalledCivil3D)
    if ($c3dList.Count -eq 0) {
        Write-Host "[!] CANH BAO: Khong tim thay Autodesk Civil 3D (2022-2026) tren may tinh nay!" -ForegroundColor Red
        Write-Host "    Luu y: Plugin yeu cau Civil 3D (khong chay tren AutoCAD thuong)." -ForegroundColor Yellow
        Export-DiagnosticReport -OpenNotepad $true
        return
    }

    $srcBundle = Join-Path $rootSetupDir "bundle"
    $hasNet8Seed = Test-Path (Join-Path $srcBundle "Contents\tsC3D.Seed.net80.dll")

    $targetBundle = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\tsC3D.bundle"
    $targetContents = Join-Path $targetBundle "Contents"
    New-Item -ItemType Directory -Force -Path $targetContents | Out-Null

    Copy-Item -LiteralPath (Join-Path $srcBundle "PackageContents.xml") -Destination (Join-Path $targetBundle "PackageContents.xml") -Force

    Get-ChildItem -Path (Join-Path $srcBundle "Contents") -File | ForEach-Object {
        $destFile = Join-Path $targetContents $_.Name
        try {
            Copy-Item -LiteralPath $_.FullName -Destination $destFile -Force -ErrorAction Stop
        } catch {
            if ($_.Name -like "tsC3D.Seed*.dll") {
                $otaDir = Join-Path $env:LOCALAPPDATA "tsC3D\Releases\current"
                New-Item -ItemType Directory -Force -Path $otaDir | Out-Null
                $sharedName = $_.Name -replace "Seed", "Shared"
                Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $otaDir $sharedName) -Force -ErrorAction SilentlyContinue
            } else {
                Write-Host "    [Luu y] File $($_.Name) dang duoc mo boi Civil 3D (hay khoi dong lai Civil 3D sau khi cai)." -ForegroundColor Yellow
            }
        }
    }

    # Remove any dev repo_root.txt if present on external PC
    $devMarker = Join-Path $targetContents "repo_root.txt"
    if ((Test-Path $devMarker) -and -not (Test-Path (Join-Path (Get-Content $devMarker -Raw).Trim() "src\LiveEntry.cs"))) {
        Remove-Item -LiteralPath $devMarker -Force -ErrorAction SilentlyContinue
    }

    Unblock-AllSetupFiles $targetBundle

    $supportedCount = 0
    foreach ($inst in $c3dList) {
        if ($inst.Net -eq "net8" -and (-not $hasNet8Seed)) {
            Write-Host "  [!] Phat hien Civil 3D $($inst.Year) (.NET 8.0): Goi hien tai chi chua ban Civil 3D 2022-2024 (.NET 4.8)." -ForegroundColor Yellow
        } else {
            Register-AutoCadTrustedPath -regSeriesPath $inst.RegKey -bundleContentsPath $targetContents
            Write-Host "  [OK] Da tich hop & cap quyen TRUSTEDPATHS cho Civil 3D $($inst.Year) ($($inst.Series))" -ForegroundColor Green
            $supportedCount++
        }
    }

    if ($supportedCount -gt 0) {
        Write-Host ""
        Write-Host "=> CAI DAT HOAN TAT CHO $supportedCount PHIEN BAN CIVIL 3D! Hay mo 'Civil 3D Metric' -> Tab 'tsC3D' (hoac go SMAP / SS)." -ForegroundColor Green
    } else {
        Write-Host ""
        Write-Host "=> May nay chi co Civil 3D 2025+ (.NET 8.0), chua co Civil 3D 2022-2024." -ForegroundColor Red
    }
}

function Export-DiagnosticReport([bool]$OpenNotepad = $true) {
    Write-Host ""
    Write-Host "Dang thu thap thong tin chan doan he thong (tu dong an ma Token ca nhan)..." -ForegroundColor Cyan

    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add("==================================================================")
    $lines.Add("     BIEN BAN CHAN DOAN CAI DAT & MOI TRUONG TSC3D (OFFLINE)      ")
    $lines.Add("==================================================================")
    $lines.Add("Thoi gian   : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
    $lines.Add("Windows OS  : $([System.Environment]::OSVersion.VersionString) (64-bit: $([System.Environment]::Is64BitOperatingSystem))")
    $lines.Add("PowerShell  : $($PSVersionTable.PSVersion)")

    $c3dList = @(Find-InstalledCivil3D)
    $lines.Add("------------------------------------------------------------------")
    $lines.Add("[1] DANH SACH CIVIL 3D PHAT HIEN TREN MAY ($($c3dList.Count)):")
    if ($c3dList.Count -eq 0) {
        $lines.Add("  [!] KHONG TIM THAY CIVIL 3D 2022-2027 (Co the chi cai AutoCAD thuong hoac doi <= 2021)!")
    } else {
        foreach ($inst in $c3dList) {
            $lines.Add("  - Civil 3D $($inst.Year) ($($inst.Series) | $($inst.Net)) -> $($inst.Dir)")
        }
    }

    $bundleDir = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\tsC3D.bundle"
    $lines.Add("------------------------------------------------------------------")
    $lines.Add("[2] TRANG THAI GOI BUNDLE TRONG APPDATA:")
    $lines.Add("  Bundle Path : $bundleDir (Ton tai: $(Test-Path $bundleDir))")
    foreach ($fn in @("PackageContents.xml", "Contents\tsC3DHotLoader.dll", "Contents\tsC3D.Seed.net48.dll", "Contents\release_channel.json")) {
        $fp = Join-Path $bundleDir $fn
        if (Test-Path $fp) {
            $fi = Get-Item -LiteralPath $fp
            $lines.Add("  - $fn : OK ($($fi.Length) bytes | $($fi.LastWriteTime.ToString('yyyy-MM-dd HH:mm')))")
        } else {
            $lines.Add("  - $fn : MISSING!")
        }
    }

    $otaDll48 = Join-Path $env:LOCALAPPDATA "tsC3D\Releases\current\tsC3D.Shared.net48.dll"
    $otaDll80 = Join-Path $env:LOCALAPPDATA "tsC3D\Releases\current\tsC3D.Shared.net80.dll"
    $otaVerFile = Join-Path $env:LOCALAPPDATA "tsC3D\Releases\current\version.txt"
    $otaVer = if (Test-Path $otaVerFile) { (Get-Content $otaVerFile -Raw).Trim() } else { "<None>" }
    $lines.Add("  OTA Payload : net48=$(Test-Path $otaDll48) | net80=$(Test-Path $otaDll80) | Version=$otaVer")

    $mapCfgPath = Join-Path $env:APPDATA "tsC3D\map_config.json"
    if (Test-Path $mapCfgPath) {
        $rawCfg = Get-Content -LiteralPath $mapCfgPath -Raw -Encoding UTF8
        $maskedCfg = [regex]::Replace($rawCfg, '("cesiumIonToken"\s*:\s*")([^"]+)(")', {
            param($m)
            $tok = $m.Groups[2].Value
            if ($tok.Length -le 10) { return $m.Groups[1].Value + "****" + $m.Groups[3].Value }
            return $m.Groups[1].Value + $tok.Substring(0, 6) + "...****..." + $tok.Substring($tok.Length - 4) + $m.Groups[3].Value
        })
        $lines.Add("  map_config  : " + ($maskedCfg -replace "\r?\n", " "))
    } else {
        $lines.Add("  map_config  : <Chua tao>")
    }

    $lines.Add("------------------------------------------------------------------")
    $lines.Add("[3] KIEM TRA KET NOI MANG HTTPS (TLS 1.2):")
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $channelFile = Join-Path $bundleDir "Contents\release_channel.json"
        $testUrl = "https://raw.githubusercontent.com/huynhphanson/tsC3D_release/main/manifest.json"
        if (Test-Path $channelFile) {
            $cj = Get-Content $channelFile -Raw | ConvertFrom-Json
            if ($cj.manifestUrl) { $testUrl = $cj.manifestUrl }
        }
        try {
            $resp = Invoke-WebRequest -Uri $testUrl -UseBasicParsing -TimeoutSec 6 -ErrorAction Stop
            $lines.Add("  GitHub Manifest : HTTP $($resp.StatusCode) OK ($testUrl)")
        } catch {
            $lines.Add("  GitHub Manifest : $($_.Exception.Message) ($testUrl)")
        }
        try {
            $cResp = Invoke-WebRequest -Uri "https://api.cesium.com" -UseBasicParsing -TimeoutSec 6 -ErrorAction Stop
            $lines.Add("  Cesium API Host : Reachable (HTTP $($cResp.StatusCode))")
        } catch {
            $lines.Add("  Cesium API Host : $($_.Exception.Message)")
        }
    } catch {
        $lines.Add("  Network Test Error: $($_.Exception.Message)")
    }

    $lines.Add("------------------------------------------------------------------")
    $lines.Add("[4] NHAT KY KHOI DONG HOTLOADER (boot.log):")
    $bootLog = Join-Path $env:LOCALAPPDATA "tsC3D\logs\boot.log"
    if (Test-Path $bootLog) {
        Get-Content -LiteralPath $bootLog -Tail 30 -Encoding UTF8 | ForEach-Object {
            $lines.Add("  " + $_)
        }
    } else {
        $lines.Add("  <Chua co boot.log -> Civil 3D chua tung nap tsC3DHotLoader.dll!>")
    }

    $outReport = Join-Path $env:USERPROFILE "Desktop\tsC3D_BaoCaoChanDoan.txt"
    if (-not (Test-Path (Split-Path -Parent $outReport))) {
        $outReport = Join-Path $rootSetupDir "tsC3D_BaoCaoChanDoan.txt"
    }
    Set-Content -LiteralPath $outReport -Value ($lines -join "`r`n") -Encoding UTF8
    Write-Host "=> Da xuat bien ban chan doan tai: $outReport" -ForegroundColor Green
    Write-Host "   Hay gui file .txt nay qua Zalo cho Tac gia de duoc ho tro ngay!" -ForegroundColor Yellow

    if ($OpenNotepad) {
        Start-Process "notepad.exe" -ArgumentList "`"$outReport`""
    }
}

function Invoke-UninstallBundle {
    $bundleDir = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\tsC3D.bundle"
    if (Test-Path $bundleDir) {
        try {
            Remove-Item -LiteralPath $bundleDir -Recurse -Force -ErrorAction Stop
            Write-Host "[OK] Da go cai dat tsC3D.bundle khoi Civil 3D (giu nguyen Token & Cache anh)." -ForegroundColor Green
        } catch {
            Write-Host "[!] Hay dong Civil 3D truoc khi go cai dat!" -ForegroundColor Red
        }
    } else {
        Write-Host "tsC3D.bundle chua duoc cai dat tren may nay." -ForegroundColor Yellow
    }
}

if ($Mode -ieq "Install") {
    Invoke-InstallBundle
    exit 0
}
if ($Mode -ieq "Diagnose") {
    Unblock-AllSetupFiles $rootSetupDir
    $c3dList = @(Find-InstalledCivil3D)
    $targetContents = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\tsC3D.bundle\Contents"
    foreach ($inst in $c3dList) {
        Register-AutoCadTrustedPath -regSeriesPath $inst.RegKey -bundleContentsPath $targetContents
    }
    Export-DiagnosticReport -OpenNotepad $true
    exit 0
}

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "   BO CAI DAT & CUU HO TU DONG TSC3D (CIVIL 3D 2022-2026) " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "  [1] Cai dat / Sua loi tu dong vao Civil 3D (Khuyen dung)"
Write-Host "  [2] Xuat Bien ban Chan doan Loi (.txt) de gui Tac gia"
Write-Host "  [3] Go cai dat tsC3D khoi Civil 3D"
Write-Host ""
$choice = Read-Host "Nhap lua chon [Mac dinh = 1]"
if ([string]::IsNullOrWhiteSpace($choice) -or $choice.Trim() -eq "1") {
    Invoke-InstallBundle
} elseif ($choice.Trim() -eq "2") {
    Export-DiagnosticReport -OpenNotepad $true
} elseif ($choice.Trim() -eq "3") {
    Invoke-UninstallBundle
}
Write-Host ""
Read-Host "Nhan Enter de dong cua so"
