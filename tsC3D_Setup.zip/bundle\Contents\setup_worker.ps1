﻿param(
    [string]$Mode = "Menu"
)

$ErrorActionPreference = "Continue"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
$scriptDir = $PSScriptRoot
$rootSetupDir = Split-Path -Parent (Split-Path -Parent $scriptDir)
if (-not (Test-Path (Join-Path $rootSetupDir "bundle\PackageContents.xml"))) {
    $rootSetupDir = Split-Path -Parent $scriptDir
}

function Unblock-AllSetupFiles($dir) {
    try {
        Get-ChildItem -Path $dir -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
            Unblock-File -LiteralPath $_.FullName -ErrorAction SilentlyContinue
        }
    } catch { }
}

function Find-InstalledCivil3D {
    $results = New-Object System.Collections.Generic.List[object]
    $seenDirs = @{}

    # 1. Dynamically scan ALL HKLM\SOFTWARE\Autodesk\AutoCAD\R* keys (catches R24.1..R24.3, R25.0..R25.2, R26.0, etc.!)
    $hklmRoot = "HKLM:\SOFTWARE\Autodesk\AutoCAD"
    if (Test-Path $hklmRoot) {
        Get-ChildItem -Path $hklmRoot -ErrorAction SilentlyContinue | ForEach-Object {
            $seriesName = $_.PSChildName
            if ($seriesName -match '^R(\d+)\.(\d+)') {
                $maj = [int]$Matches[1]
                $min = [int]$Matches[2]
                if ($maj -ge 24) {
                    $netKind = if ($maj -ge 25) { "net80" } else { "net48" }
                    Get-ChildItem -Path $_.PSPath -ErrorAction SilentlyContinue | ForEach-Object {
                        $prodId = $_.PSChildName
                        $props = Get-ItemProperty -Path $_.PSPath -ErrorAction SilentlyContinue
                        $loc = if ($props -and $props.AcadLocation) { ($props.AcadLocation -as [string]).Trim().TrimEnd('\') } else { "" }
                        $relName = if ($props -and $props.ProductName) { ($props.ProductName -as [string]).Trim() } else { "Civil 3D ($seriesName)" }
                        if (-not [string]::IsNullOrWhiteSpace($loc) -and
                            (Test-Path (Join-Path $loc "AcCoreMgd.dll")) -and
                            (Test-Path (Join-Path $loc "C3D\AeccDbMgd.dll"))) {
                            $keySig = "$seriesName|$prodId"
                            if (-not $seenDirs.ContainsKey($keySig)) {
                                $seenDirs[$keySig] = $true
                                $results.Add([PSCustomObject]@{
                                    Label      = $relName
                                    Series     = $seriesName
                                    ProdId     = $prodId
                                    Net        = $netKind
                                    Dir        = $loc
                                    HkcuSeries = "HKCU:\Software\Autodesk\AutoCAD\$seriesName"
                                    HkcuProd   = "HKCU:\Software\Autodesk\AutoCAD\$seriesName\$prodId"
                                })
                            }
                        }
                    }
                }
            }
        }
    }

    # 2. Fallback disk scan if HKLM wasn't populated
    if ($results.Count -eq 0) {
        $fallbackMap = @(
            @{ Year = 2027; Series = "R26.0"; Net = "net80" },
            @{ Year = 2027; Series = "R25.2"; Net = "net80" },
            @{ Year = 2026; Series = "R25.1"; Net = "net80" },
            @{ Year = 2025; Series = "R25.0"; Net = "net80" },
            @{ Year = 2024; Series = "R24.3"; Net = "net48" },
            @{ Year = 2023; Series = "R24.2"; Net = "net48" },
            @{ Year = 2022; Series = "R24.1"; Net = "net48" }
        )
        foreach ($f in $fallbackMap) {
            foreach ($drv in @("C", "D", "E", "F")) {
                $d = "${drv}:\Program Files\Autodesk\AutoCAD $($f.Year)"
                if ((Test-Path (Join-Path $d "AcCoreMgd.dll")) -and (Test-Path (Join-Path $d "C3D\AeccDbMgd.dll")) -and (-not $seenDirs.ContainsKey($d))) {
                    $seenDirs[$d] = $true
                    $results.Add([PSCustomObject]@{
                        Label      = "Autodesk Civil 3D $($f.Year)"
                        Series     = $f.Series
                        ProdId     = ""
                        Net        = $f.Net
                        Dir        = $d
                        HkcuSeries = "HKCU:\Software\Autodesk\AutoCAD\$($f.Series)"
                        HkcuProd   = ""
                    })
                }
            }
        }
    }

    return $results
}

function Register-Civil3DStartupAndTrust($inst, $bundleRootPath) {
    $loaderSubDir = if ($inst.Net -eq "net80") { "Contents\net80" } else { "Contents\net48" }
    $loaderDllPath = Join-Path $bundleRootPath "$loaderSubDir\tsC3DHotLoader.dll"
    if (-not (Test-Path $loaderDllPath)) { return $false }

    # Collect target HKCU product keys (e.g. ACAD-5100:409, ACAD-8100:409, etc.)
    $prodKeys = New-Object System.Collections.Generic.List[string]
    if (-not [string]::IsNullOrWhiteSpace($inst.HkcuProd)) {
        if (-not (Test-Path $inst.HkcuProd)) {
            New-Item -Path $inst.HkcuProd -Force -ErrorAction SilentlyContinue | Out-Null
        }
        $prodKeys.Add($inst.HkcuProd)
    }
    if (Test-Path $inst.HkcuSeries) {
        Get-ChildItem -Path $inst.HkcuSeries -ErrorAction SilentlyContinue | ForEach-Object {
            if ($_.PSChildName -like "ACAD-*" -and (-not $prodKeys.Contains($_.PSPath))) {
                $prodKeys.Add($_.PSPath)
            }
        }
    }

    $trustRecursiveEntry = "$bundleRootPath\..."

    foreach ($pk in $prodKeys) {
        # A) Register native AutoCAD Demand-Load Startup entry (works 100% even when APPAUTOLOAD=0!)
        try {
            $appKey = Join-Path $pk "Applications\tsC3DHotLoader"
            New-Item -Path $appKey -Force -ErrorAction SilentlyContinue | Out-Null
            New-ItemProperty -Path $appKey -Name "DESCRIPTION" -Value "tsC3D Engineering Tools" -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null
            New-ItemProperty -Path $appKey -Name "LOADER" -Value $loaderDllPath -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null
            New-ItemProperty -Path $appKey -Name "LOADCTRLS" -Value 2 -PropertyType DWord -Force -ErrorAction SilentlyContinue | Out-Null
            New-ItemProperty -Path $appKey -Name "MANAGED" -Value 1 -PropertyType DWord -Force -ErrorAction SilentlyContinue | Out-Null
        } catch { }

        # B) Register TRUSTEDPATHS (with valid '\...' syntax!) & APPAUTOLOAD across all Profiles
        $profilesRoot = Join-Path $pk "Profiles"
        if (Test-Path $profilesRoot) {
            Get-ChildItem -Path $profilesRoot -ErrorAction SilentlyContinue | ForEach-Object {
                $varsKey = Join-Path $_.PSPath "Variables"
                if (-not (Test-Path $varsKey)) {
                    New-Item -Path $varsKey -Force -ErrorAction SilentlyContinue | Out-Null
                }
                try {
                    Set-ItemProperty -Path $varsKey -Name "APPAUTOLOAD" -Value "14" -ErrorAction SilentlyContinue
                    $curTrust = (Get-ItemProperty -Path $varsKey -Name "TRUSTEDPATHS" -ErrorAction SilentlyContinue).TRUSTEDPATHS
                    if ([string]::IsNullOrWhiteSpace($curTrust)) {
                        Set-ItemProperty -Path $varsKey -Name "TRUSTEDPATHS" -Value $trustRecursiveEntry -ErrorAction SilentlyContinue
                    } else {
                        # Clean any old malformed entry without backslash before '...'
                        $parts = @($curTrust -split ';' | Where-Object { $_ -ne "" -and $_ -notlike "*tsC3D.bundle*" })
                        $parts += $trustRecursiveEntry
                        Set-ItemProperty -Path $varsKey -Name "TRUSTEDPATHS" -Value ($parts -join ';') -ErrorAction SilentlyContinue
                    }
                } catch { }
            }
        }
    }
    return $true
}

function Invoke-InstallBundle {
    Write-Host ""
    Write-Host "=== CAI DAT CONG CU TSC3D CHO AUTODESK CIVIL 3D (2022 - 2027+) ===" -ForegroundColor Cyan
    Unblock-AllSetupFiles $rootSetupDir

    $runningAcad = @(Get-Process -Name "acad" -ErrorAction SilentlyContinue)
    if ($runningAcad.Count -gt 0 -and $Mode -ine "Install") {
        Write-Host "[!] PHAT HIEN CIVIL 3D / AUTOCAD DANG MO!" -ForegroundColor Yellow
        Write-Host "    Hay LUU BAN VE & DONG CIVIL 3D truoc de dang ky TRUSTEDPATHS sach 100%," -ForegroundColor Yellow
        Write-Host "    sau do nhan Enter de tiep tuc..." -ForegroundColor Yellow
        Read-Host "    Nhan Enter sau khi da dong Civil 3D"
    }

    $c3dList = @(Find-InstalledCivil3D)
    if ($c3dList.Count -eq 0) {
        Write-Host "[!] CANH BAO: Khong tim thay Autodesk Civil 3D (2022-2027) tren may tinh nay!" -ForegroundColor Red
        Export-DiagnosticReport -OpenNotepad $true
        return
    }

    $srcBundle = Join-Path $rootSetupDir "bundle"
    $targetBundle = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\tsC3D.bundle"
    New-Item -ItemType Directory -Force -Path $targetBundle | Out-Null

    try {
        Copy-Item -Path (Join-Path $srcBundle "*") -Destination $targetBundle -Recurse -Force -ErrorAction Stop
    } catch {
        Write-Host "    [Luu y] Mot so file dang duoc mo boi Civil 3D (hay khoi dong lai Civil 3D sau khi cai)." -ForegroundColor Yellow
    }

    # Remove any leftover dev marker on external PC
    $devMarker = Join-Path $targetBundle "Contents\repo_root.txt"
    if ((Test-Path $devMarker) -and -not (Test-Path (Join-Path (Get-Content $devMarker -Raw).Trim() "src\LiveEntry.cs"))) {
        Remove-Item -LiteralPath $devMarker -Force -ErrorAction SilentlyContinue
    }

    Unblock-AllSetupFiles $targetBundle

    $okCount = 0
    foreach ($inst in $c3dList) {
        if (Register-Civil3DStartupAndTrust -inst $inst -bundleRootPath $targetBundle) {
            Write-Host "  [OK] Da tich hop cho $($inst.Label) [$($inst.Series) | $($inst.Net)]" -ForegroundColor Green
            $okCount++
        } else {
            Write-Host "  [!] Chua co nhan $($inst.Net) cho $($inst.Label)" -ForegroundColor Yellow
        }
    }

    Write-Host ""
    Write-Host "=> CAI DAT HOAN TAT CHO $okCount PHIEN BAN CIVIL 3D!" -ForegroundColor Green
    Write-Host "   Hay mo 'Civil 3D Metric' (2022..2027) -> Tab 'tsC3D' (hoac go SMAP / SS)." -ForegroundColor Cyan
}

function Export-DiagnosticReport([bool]$OpenNotepad = $true) {
    Write-Host ""
    Write-Host "Dang thu thap thong tin chan doan he thong (tu dong an ma Token ca nhan)..." -ForegroundColor Cyan

    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add("==================================================================")
    $lines.Add("     BIEN BAN CHAN DOAN CAI DAT & MOI TRUONG TSC3D (OFFLINE)      ")
    $lines.Add("==================================================================")
    $lines.Add("Thoi gian   : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
    $lines.Add("Windows OS  : $([System.Environment]::OSVersion.VersionString) (64-bit: $([System.Environment]::Is64BitOperatingSystem))")
    $lines.Add("PowerShell  : $($PSVersionTable.PSVersion)")

    $c3dList = @(Find-InstalledCivil3D)
    $lines.Add("------------------------------------------------------------------")
    $lines.Add("[1] DANH SACH CIVIL 3D PHAT HIEN TREN MAY ($($c3dList.Count)):")
    if ($c3dList.Count -eq 0) {
        $lines.Add("  [!] KHONG TIM THAY CIVIL 3D 2022-2027!")
    } else {
        foreach ($inst in $c3dList) {
            $lines.Add("  - $($inst.Label) ($($inst.Series) | $($inst.ProdId) | $($inst.Net)) -> $($inst.Dir)")
            if (-not [string]::IsNullOrWhiteSpace($inst.HkcuProd) -and (Test-Path $inst.HkcuProd)) {
                $appLoader = (Get-ItemProperty -Path (Join-Path $inst.HkcuProd "Applications\tsC3DHotLoader") -ErrorAction SilentlyContinue).LOADER
                $lines.Add("      StartupReg : $(if ($appLoader) { "OK ($appLoader)" } else { "<Missing>" })")
                $profDir = Join-Path $inst.HkcuProd "Profiles"
                if (Test-Path $profDir) {
                    Get-ChildItem -Path $profDir -ErrorAction SilentlyContinue | Select-Object -First 3 | ForEach-Object {
                        $vp = Join-Path $_.PSPath "Variables"
                        if (Test-Path $vp) {
                            $vObj = Get-ItemProperty -Path $vp -ErrorAction SilentlyContinue
                            $lines.Add("      Profile [$($_.PSChildName)] : SECURELOAD=$($vObj.SECURELOAD) | APPAUTOLOAD=$($vObj.APPAUTOLOAD) | BundleTrusted=$($vObj.TRUSTEDPATHS -like '*tsC3D.bundle*')")
                        }
                    }
                }
            }
        }
    }

    $bundleDir = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\tsC3D.bundle"
    $lines.Add("------------------------------------------------------------------")
    $lines.Add("[2] TRANG THAI GOI BUNDLE TRONG APPDATA:")
    $lines.Add("  Bundle Path : $bundleDir (Ton tai: $(Test-Path $bundleDir))")
    foreach ($fn in @(
        "PackageContents.xml",
        "Contents\release_channel.json",
        "Contents\net48\tsC3DHotLoader.dll",
        "Contents\net48\tsC3D.Seed.net48.dll",
        "Contents\net80\tsC3DHotLoader.dll",
        "Contents\net80\tsC3D.Seed.net80.dll"
    )) {
        $fp = Join-Path $bundleDir $fn
        if (Test-Path $fp) {
            $fi = Get-Item -LiteralPath $fp
            $lines.Add("  - $fn : OK ($($fi.Length) bytes | $($fi.LastWriteTime.ToString('yyyy-MM-dd HH:mm')))")
        } else {
            $lines.Add("  - $fn : MISSING")
        }
    }

    $otaDll48 = Join-Path $env:LOCALAPPDATA "tsC3D\Releases\current\tsC3D.Shared.net48.dll"
    $otaDll80 = Join-Path $env:LOCALAPPDATA "tsC3D\Releases\current\tsC3D.Shared.net80.dll"
    $otaVerFile = Join-Path $env:LOCALAPPDATA "tsC3D\Releases\current\version.txt"
    $otaVer = if (Test-Path $otaVerFile) { (Get-Content $otaVerFile -Raw).Trim() } else { "<None>" }
    $lines.Add("  OTA Payload : net48=$(Test-Path $otaDll48) | net80=$(Test-Path $otaDll80) | Version=$otaVer")

    $mapCfgPath = Join-Path $env:APPDATA "tsC3D\map_config.json"
    if (Test-Path $mapCfgPath) {
        $rawCfg = Get-Content -LiteralPath $mapCfgPath -Raw -Encoding UTF8
        $maskedCfg = [regex]::Replace($rawCfg, '("cesiumIonToken"\s*:\s*")([^"]+)(")', {
            param($m)
            $tok = $m.Groups[2].Value
            if ($tok.Length -le 10) { return $m.Groups[1].Value + "****" + $m.Groups[3].Value }
            return $m.Groups[1].Value + $tok.Substring(0, 6) + "...****..." + $tok.Substring($tok.Length - 4) + $m.Groups[3].Value
        })
        $lines.Add("  map_config  : " + ($maskedCfg -replace "\r?\n", " "))
    } else {
        $lines.Add("  map_config  : <Chua tao>")
    }

    $lines.Add("------------------------------------------------------------------")
    $lines.Add("[3] KIEM TRA KET NOI MANG HTTPS (TLS 1.2):")
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $channelFile = Join-Path $bundleDir "Contents\release_channel.json"
        $testUrl = "https://raw.githubusercontent.com/huynhphanson/tsC3D_release/main/manifest.json"
        if (Test-Path $channelFile) {
            $cj = Get-Content $channelFile -Raw | ConvertFrom-Json
            if ($cj.manifestUrl) { $testUrl = $cj.manifestUrl }
        }
        try {
            $resp = Invoke-WebRequest -Uri $testUrl -UseBasicParsing -TimeoutSec 6 -ErrorAction Stop
            $lines.Add("  GitHub Manifest : HTTP $($resp.StatusCode) OK ($testUrl)")
        } catch {
            $lines.Add("  GitHub Manifest : $($_.Exception.Message) ($testUrl)")
        }
        try {
            $cResp = Invoke-WebRequest -Uri "https://api.cesium.com" -UseBasicParsing -TimeoutSec 6 -ErrorAction Stop
            $lines.Add("  Cesium API Host : OK (HTTP $($cResp.StatusCode))")
        } catch {
            $wex = $_.Exception -as [System.Net.WebException]
            if ($wex -and $wex.Response) {
                $code = [int]($wex.Response -as [System.Net.HttpWebResponse]).StatusCode
                $lines.Add("  Cesium API Host : OK - Ket noi HTTPS thong suot (HTTP $code)")
            } else {
                $lines.Add("  Cesium API Host : LOI KET NOI - $($_.Exception.Message)")
            }
        }
    } catch {
        $lines.Add("  Network Test Error: $($_.Exception.Message)")
    }

    $lines.Add("------------------------------------------------------------------")
    $lines.Add("[4] NHAT KY KHOI DONG HOTLOADER (boot.log):")
    $bootLog = Join-Path $env:LOCALAPPDATA "tsC3D\logs\boot.log"
    if (Test-Path $bootLog) {
        Get-Content -LiteralPath $bootLog -Tail 35 -Encoding UTF8 | ForEach-Object {
            $lines.Add("  " + $_)
        }
    } else {
        $lines.Add("  <Chua co boot.log -> Civil 3D chua tung nap tsC3DHotLoader.dll!>")
    }

    $outReport = Join-Path $env:USERPROFILE "Desktop\tsC3D_BaoCaoChanDoan.txt"
    if (-not (Test-Path (Split-Path -Parent $outReport))) {
        $outReport = Join-Path $rootSetupDir "tsC3D_BaoCaoChanDoan.txt"
    }
    Set-Content -LiteralPath $outReport -Value ($lines -join "`r`n") -Encoding UTF8
    Write-Host "=> Da xuat bien ban chan doan tai: $outReport" -ForegroundColor Green
    Write-Host "   Hay gui file .txt nay qua Zalo cho Tac gia de duoc ho tro ngay!" -ForegroundColor Yellow

    if ($OpenNotepad) {
        Start-Process "notepad.exe" -ArgumentList "`"$outReport`""
    }
}

function Invoke-UninstallBundle {
    $c3dList = @(Find-InstalledCivil3D)
    foreach ($inst in $c3dList) {
        if (-not [string]::IsNullOrWhiteSpace($inst.HkcuProd)) {
            $appKey = Join-Path $inst.HkcuProd "Applications\tsC3DHotLoader"
            if (Test-Path $appKey) { Remove-Item -Path $appKey -Recurse -Force -ErrorAction SilentlyContinue }
        }
    }
    $bundleDir = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\tsC3D.bundle"
    if (Test-Path $bundleDir) {
        try {
            Remove-Item -LiteralPath $bundleDir -Recurse -Force -ErrorAction Stop
            Write-Host "[OK] Da go cai dat tsC3D khoi tat ca phien ban Civil 3D (giu nguyen Token & Cache anh)." -ForegroundColor Green
        } catch {
            Write-Host "[!] Hay dong Civil 3D truoc khi go cai dat!" -ForegroundColor Red
        }
    } else {
        Write-Host "tsC3D.bundle chua duoc cai dat tren may nay." -ForegroundColor Yellow
    }
}

if ($Mode -ieq "Install") {
    Invoke-InstallBundle
    exit 0
}
if ($Mode -ieq "Diagnose") {
    Unblock-AllSetupFiles $rootSetupDir
    $c3dList = @(Find-InstalledCivil3D)
    $targetBundle = Join-Path $env:APPDATA "Autodesk\ApplicationPlugins\tsC3D.bundle"
    foreach ($inst in $c3dList) {
        Register-Civil3DStartupAndTrust -inst $inst -bundleRootPath $targetBundle | Out-Null
    }
    Export-DiagnosticReport -OpenNotepad $true
    exit 0
}

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "   BO CAI DAT & CUU HO TU DONG TSC3D (CIVIL 3D 2022-2027) " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "  [1] Cai dat / Sua loi tu dong vao Civil 3D (Khuyen dung)"
Write-Host "  [2] Xuat Bien ban Chan doan Loi (.txt) de gui Tac gia"
Write-Host "  [3] Go cai dat tsC3D khoi Civil 3D"
Write-Host ""
$choice = Read-Host "Nhap lua chon [Mac dinh = 1]"
if ([string]::IsNullOrWhiteSpace($choice) -or $choice.Trim() -eq "1") {
    Invoke-InstallBundle
} elseif ($choice.Trim() -eq "2") {
    Export-DiagnosticReport -OpenNotepad $true
} elseif ($choice.Trim() -eq "3") {
    Invoke-UninstallBundle
}
Write-Host ""
Read-Host "Nhan Enter de dong cua so"